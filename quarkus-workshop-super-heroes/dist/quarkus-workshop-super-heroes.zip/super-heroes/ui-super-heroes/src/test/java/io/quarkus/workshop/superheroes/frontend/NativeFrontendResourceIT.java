package io.quarkus.workshop.superheroes.frontend;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeFrontendResourceIT extends FrontendResourceTest {

    // Execute the same tests but in native mode.
}